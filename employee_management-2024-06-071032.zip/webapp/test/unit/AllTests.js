sap.ui.define([
	"comibspl/employee_management/test/unit/controller/Emp_Management_Master.controller"
], function () {
	"use strict";
});
